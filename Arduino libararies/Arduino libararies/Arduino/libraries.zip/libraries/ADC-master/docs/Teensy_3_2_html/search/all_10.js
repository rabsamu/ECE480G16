var searchData=
[
  ['very_5fhigh_5fspeed_126',['VERY_HIGH_SPEED',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688ea605020f3fad4a24098fbbb0fa4a293f1',1,'ADC_settings::VERY_HIGH_SPEED()'],['../namespace_a_d_c__settings.html#af0d80a1aae7288f77b13f0e01d9da0d3a605020f3fad4a24098fbbb0fa4a293f1',1,'ADC_settings::VERY_HIGH_SPEED()']]],
  ['very_5flow_5fspeed_127',['VERY_LOW_SPEED',['../namespace_a_d_c__settings.html#aab853fc1fcb1992fd5d51408adf7688ea5afd4ce3e51232e5889cfd918354ff2d',1,'ADC_settings::VERY_LOW_SPEED()'],['../namespace_a_d_c__settings.html#af0d80a1aae7288f77b13f0e01d9da0d3a5afd4ce3e51232e5889cfd918354ff2d',1,'ADC_settings::VERY_LOW_SPEED()']]],
  ['vref_128',['VREF',['../namespace_v_r_e_f.html',1,'']]],
  ['vref_5fout_129',['VREF_OUT',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2a7cfb6990906e489b3f7b7d351fc1c106',1,'ADC_settings']]],
  ['vrefh_130',['VREFH',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2a1f5248caa2d2138480493dd069530462',1,'ADC_settings']]],
  ['vrefl_131',['VREFL',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2ab546f9ad5f80e932f2fd1038bbaddaa8',1,'ADC_settings']]]
];
